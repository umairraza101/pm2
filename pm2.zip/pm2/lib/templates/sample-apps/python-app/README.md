
# Managing a Python Application

On this boilerlate you will see how you can start a Python application with PM2.
