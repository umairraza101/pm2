setInterval(function() {
  console.log(process.env.TEST_VARIABLE);
}, 100);
