"use strict";
var models_1 = require('./models');
console.log(models_1.UserMessage);
setTimeout(function () {
    throw new Error('errr');
}, 1000);
//# sourceMappingURL=main.js.map
