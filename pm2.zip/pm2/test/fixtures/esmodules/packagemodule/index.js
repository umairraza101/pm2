import { area, circumference } from './circle.js';

const r = 3;

console.log(`Circle with radius ${r} has
  area: ${area(r)};
  circunference: ${circumference(r)}`);

setInterval(() => {
}, 1000)
