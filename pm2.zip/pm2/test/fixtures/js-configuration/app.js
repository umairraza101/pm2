
setInterval(function() {
  console.log('ok');
}, 1000);
