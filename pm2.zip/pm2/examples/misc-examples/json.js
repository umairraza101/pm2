
setInterval(function() {
  console.log({
    hey : 'hay',
    ho : {
      si : 'si',
      ca : ['boum']
    }
  });
  var a = {a: 'a', b: 'b'};
  console.log(a);
}, 1000);
