

setTimeout(function() {
  throw new Error('ok');
}, 1100);
