
console.log(process.env.PASSED_VARIABLE);
