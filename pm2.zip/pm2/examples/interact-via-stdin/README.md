
To interact with an app readin on stdin:


```
$ pm2 start stdin.js
```

Then to attach to it:

```
$ pm2 attach 0
```
