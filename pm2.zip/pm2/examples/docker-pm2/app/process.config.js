module.exports = {
  apps : [{
    name   : "express-app",
    script : "./app.js"
  }]
}
