
const pmx = require('pmx');

setInterval(function() {
  pmx.notify({ success : false });
}, 200);
